import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const resources = {
  en: {
    translation: {
      commodity: "Commodity",
      state: "State",
      get_forecast: "Get Forecast",
      loading: "Analyzing...",
      price_trend: "Price Trend",
      weather_forecast: "7-Day Weather",
      market_news: "Market News",
      no_news: "No recent news found.",
      select_prompt: "Select a commodity and state to get your sell/hold signal.",
    },
  },
  hi: {
    translation: {
      commodity: "फसल",
      state: "राज्य",
      get_forecast: "पूर्वानुमान देखें",
      loading: "विश्लेषण हो रहा है...",
      price_trend: "मूल्य प्रवृत्ति",
      weather_forecast: "7 दिन का मौसम",
      market_news: "बाजार समाचार",
      no_news: "कोई हालिया समाचार नहीं मिला।",
      select_prompt: "फसल और राज्य चुनें और बेचने/रोकने का संकेत पाएं।",
    },
  },
  mr: {
    translation: {
      commodity: "पीक",
      state: "राज्य",
      get_forecast: "अंदाज पाहा",
      loading: "विश्लेषण सुरू...",
      price_trend: "किंमत कल",
      weather_forecast: "७ दिवसांचे हवामान",
      market_news: "बाजार बातम्या",
      no_news: "कोणत्याही अलीकडील बातम्या नाहीत.",
      select_prompt: "पीक आणि राज्य निवडा आणि विकण्याचा/थांबण्याचा संकेत मिळवा।",
    },
  },
};

i18n.use(initReactI18next).init({
  resources,
  lng: "en",
  fallbackLng: "en",
  interpolation: { escapeValue: false },
});

export default i18n;
