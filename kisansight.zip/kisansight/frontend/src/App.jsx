import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import Dashboard from "./pages/Dashboard";
import "./i18n";

export default function App() {
  const { i18n } = useTranslation();
  const [lang, setLang] = useState("en");

  const changeLang = (l) => {
    setLang(l);
    i18n.changeLanguage(l);
  };

  return (
    <div className="min-h-screen bg-green-50">
      <header className="bg-green-700 text-white px-4 py-3 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🌾</span>
          <span className="text-xl font-bold tracking-wide">KisanSight</span>
          <span className="text-xs bg-green-500 px-2 py-0.5 rounded-full">Beta</span>
        </div>
        <div className="flex gap-1">
          {["en", "hi", "mr"].map((l) => (
            <button
              key={l}
              onClick={() => changeLang(l)}
              className={`px-3 py-1 rounded text-sm font-medium transition ${
                lang === l ? "bg-white text-green-700" : "hover:bg-green-600"
              }`}
            >
              {l === "en" ? "English" : l === "hi" ? "हिंदी" : "मराठी"}
            </button>
          ))}
        </div>
      </header>
      <Dashboard lang={lang} />
    </div>
  );
}
