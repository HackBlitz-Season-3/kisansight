import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

export default function ForecastChart({ forecast }) {
  const ref = useRef(null);
  const chartRef = useRef(null);

  useEffect(() => {
    if (!forecast || !ref.current) return;

    if (chartRef.current) chartRef.current.destroy();

    const historical = forecast.historical || [];
    const futurePreds = forecast.forecast || [];

    const histLabels = historical.map(d => new Date(d.date).toLocaleDateString("en-IN", { month: "short", day: "numeric" }));
    const histPrices = historical.map(d => d.price);

    const futureLabels = futurePreds.map(d => new Date(d.date).toLocaleDateString("en-IN", { month: "short", day: "numeric" }));
    const futurePrices = futurePreds.map(d => d.price);
    const futureUpper = futurePreds.map(d => d.upper);
    const futureLower = futurePreds.map(d => d.lower);

    const allLabels = [...histLabels, ...futureLabels];

    chartRef.current = new Chart(ref.current, {
      type: "line",
      data: {
        labels: allLabels,
        datasets: [
          {
            label: "Historical Price",
            data: [...histPrices, ...new Array(futureLabels.length).fill(null)],
            borderColor: "#16a34a",
            backgroundColor: "rgba(22,163,74,0.1)",
            borderWidth: 2,
            pointRadius: 2,
            tension: 0.3,
            fill: true,
          },
          {
            label: "Forecast",
            data: [...new Array(histLabels.length).fill(null), ...futurePrices],
            borderColor: "#f97316",
            borderDash: [5, 5],
            borderWidth: 2.5,
            pointRadius: 4,
            tension: 0.3,
          },
          {
            label: "Forecast Upper",
            data: [...new Array(histLabels.length).fill(null), ...futureUpper],
            borderColor: "rgba(249,115,22,0.2)",
            backgroundColor: "rgba(249,115,22,0.08)",
            borderWidth: 1,
            pointRadius: 0,
            fill: "+1",
          },
          {
            label: "Forecast Lower",
            data: [...new Array(histLabels.length).fill(null), ...futureLower],
            borderColor: "rgba(249,115,22,0.2)",
            borderWidth: 1,
            pointRadius: 0,
            fill: false,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: "top", labels: { usePointStyle: true, font: { size: 12 } } },
          tooltip: {
            callbacks: {
              label: ctx => `₹${ctx.parsed.y?.toFixed(0)} / quintal`,
            },
          },
        },
        scales: {
          y: {
            title: { display: true, text: "Price (₹/quintal)" },
            grid: { color: "rgba(0,0,0,0.05)" },
          },
          x: { grid: { display: false } },
        },
      },
    });
  }, [forecast]);

  return <canvas ref={ref} height={100} />;
}
