export default function SignalBadge({ forecast, explanation }) {
  if (!forecast) return null;
  const isSell = forecast.signal === "SELL TODAY";

  return (
    <div className={`rounded-2xl shadow-lg p-6 text-white ${isSell ? "bg-orange-500" : "bg-green-600"}`}>
      <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
        <div className="text-5xl">{isSell ? "🛒" : "⏳"}</div>
        <div className="flex-1">
          <div className="text-3xl font-black tracking-tight">{forecast.signal}</div>
          <div className="mt-1 text-sm opacity-90">
            Today: <span className="font-bold">₹{forecast.today_price}/qtl</span>
            {!isSell && (
              <span className="ml-3">
                Expected in 3 days: <span className="font-bold">₹{forecast.predicted_price_3d}/qtl</span>
                <span className="ml-2 bg-white/20 px-2 py-0.5 rounded-full text-xs font-semibold">
                  {forecast.gain_pct > 0 ? "+" : ""}{forecast.gain_pct}%
                </span>
              </span>
            )}
          </div>
        </div>
      </div>
      {explanation && (
        <div className="mt-4 bg-white/15 rounded-xl p-3 text-sm leading-relaxed">
          {explanation}
        </div>
      )}
    </div>
  );
}
