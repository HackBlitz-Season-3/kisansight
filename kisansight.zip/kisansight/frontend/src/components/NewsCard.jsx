import { useTranslation } from "react-i18next";

export default function NewsCard({ news, commodity }) {
  const { t } = useTranslation();

  return (
    <div className="bg-white rounded-xl shadow p-4">
      <h2 className="font-semibold text-gray-700 mb-3">📰 {t("market_news")} — {commodity}</h2>
      {!news?.length ? (
        <p className="text-sm text-gray-400">{t("no_news")}</p>
      ) : (
        <ul className="space-y-3">
          {news.map((item, i) => (
            <li key={i} className="border-b last:border-0 pb-2 last:pb-0">
              <a
                href={item.url}
                target="_blank"
                rel="noreferrer"
                className="text-sm font-medium text-green-700 hover:underline line-clamp-2"
              >
                {item.title}
              </a>
              <p className="text-xs text-gray-400 mt-0.5">{item.source} · {item.published?.slice(0, 10)}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
