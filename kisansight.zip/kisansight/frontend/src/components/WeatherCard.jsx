import { useTranslation } from "react-i18next";

const weatherIcon = (rain) => {
  if (rain > 10) return "🌧️";
  if (rain > 2) return "🌦️";
  return "☀️";
};

export default function WeatherCard({ weather }) {
  const { t } = useTranslation();
  if (!weather || weather.error || !weather.dates) return null;

  const days = weather.dates.slice(0, 5).map((date, i) => ({
    date: new Date(date).toLocaleDateString("en-IN", { weekday: "short", day: "numeric" }),
    tmax: weather.temp_max?.[i],
    tmin: weather.temp_min?.[i],
    rain: weather.precipitation?.[i],
  }));

  return (
    <div className="bg-white rounded-xl shadow p-4">
      <h2 className="font-semibold text-gray-700 mb-3">🌤️ {t("weather_forecast")}</h2>
      <div className="space-y-2">
        {days.map((d, i) => (
          <div key={i} className="flex items-center justify-between text-sm">
            <span className="w-24 text-gray-500">{d.date}</span>
            <span className="text-xl">{weatherIcon(d.rain)}</span>
            <span className="text-gray-700">{d.tmin}° – {d.tmax}°C</span>
            <span className="text-blue-500">{d.rain?.toFixed(1)} mm</span>
          </div>
        ))}
      </div>
    </div>
  );
}
