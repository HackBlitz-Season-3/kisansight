import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import ForecastChart from "../components/ForecastChart";
import WeatherCard from "../components/WeatherCard";
import NewsCard from "../components/NewsCard";
import SignalBadge from "../components/SignalBadge";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

export default function Dashboard({ lang }) {
  const { t } = useTranslation();
  const [commodities, setCommodities] = useState([]);
  const [states, setStates] = useState([]);
  const [commodity, setCommodity] = useState("");
  const [state, setState] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`${API}/api/commodities`).then(r => r.json()).then(d => {
      setCommodities(d.commodities);
      setCommodity(d.commodities[0] || "");
    });
    fetch(`${API}/api/states`).then(r => r.json()).then(d => {
      setStates(d.states);
      setState(d.states[0] || "");
    });
  }, []);

  const fetchForecast = async () => {
    if (!commodity || !state) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/predict?commodity=${encodeURIComponent(commodity)}&state=${encodeURIComponent(state)}&lang=${lang}`);
      const json = await res.json();
      setData(json);
    } catch (e) {
      setError("Failed to fetch forecast. Please try again.");
    }
    setLoading(false);
  };

  return (
    <main className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Selector Row */}
      <div className="bg-white rounded-xl shadow p-4 flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-40">
          <label className="block text-xs font-semibold text-gray-500 mb-1">{t("commodity")}</label>
          <select
            value={commodity}
            onChange={e => setCommodity(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-green-400 outline-none"
          >
            {commodities.map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="flex-1 min-w-40">
          <label className="block text-xs font-semibold text-gray-500 mb-1">{t("state")}</label>
          <select
            value={state}
            onChange={e => setState(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-green-400 outline-none"
          >
            {states.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <button
          onClick={fetchForecast}
          disabled={loading}
          className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded-lg transition disabled:opacity-50"
        >
          {loading ? t("loading") : t("get_forecast")}
        </button>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-4">{error}</div>}

      {data && (
        <>
          {/* Big Signal */}
          <SignalBadge forecast={data.forecast} explanation={data.explanation} />

          {/* Chart */}
          <div className="bg-white rounded-xl shadow p-4">
            <h2 className="font-semibold text-gray-700 mb-3">{t("price_trend")} — {commodity} ({state})</h2>
            <ForecastChart forecast={data.forecast} />
          </div>

          {/* Weather + News */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <WeatherCard weather={data.weather} />
            <NewsCard news={data.news} commodity={commodity} />
          </div>
        </>
      )}

      {!data && !loading && (
        <div className="text-center text-gray-400 py-20 text-lg">
          🌱 {t("select_prompt")}
        </div>
      )}
    </main>
  );
}
