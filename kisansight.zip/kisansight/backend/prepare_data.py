"""
Run this once to convert agriprice_dataset.xlsx -> data/prices.csv
Usage: python prepare_data.py path/to/agriprice_dataset.xlsx
"""
import pandas as pd
import sys
import os

xlsx_path = sys.argv[1] if len(sys.argv) > 1 else "agriprice_dataset.xlsx"
out_dir = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(out_dir, exist_ok=True)

df = pd.read_excel(xlsx_path, sheet_name="1_Historical_Prices", header=1, skiprows=1)

keep = ["Date", "Commodity", "State", "Mandi", "Modal_Price_INR_Quintal",
        "Min_Price_INR_Quintal", "Max_Price_INR_Quintal", "Arrival_Qtl", "MSP_INR_Quintal"]
df = df[keep].dropna(subset=["Date", "Modal_Price_INR_Quintal"])
df["Date"] = pd.to_datetime(df["Date"])
df.to_csv(os.path.join(out_dir, "prices.csv"), index=False)
print(f"Saved {len(df)} rows to data/prices.csv")
print("Commodities:", df["Commodity"].unique().tolist())
print("States:", df["State"].unique().tolist())
