import httpx

# Approximate lat/lon for major Indian states
STATE_COORDS = {
    "Maharashtra": (19.7515, 75.7139),
    "Punjab": (31.1471, 75.3412),
    "Uttar Pradesh": (26.8467, 80.9462),
    "Karnataka": (15.3173, 75.7139),
    "Madhya Pradesh": (22.9734, 78.6569),
    "Rajasthan": (27.0238, 74.2179),
    "Gujarat": (22.2587, 71.1924),
    "Andhra Pradesh": (15.9129, 79.7400),
    "Tamil Nadu": (11.1271, 78.6569),
    "West Bengal": (22.9868, 87.8550),
    "Haryana": (29.0588, 76.0856),
    "Bihar": (25.0961, 85.3131),
}

def get_weather(state: str) -> dict:
    coords = STATE_COORDS.get(state, (20.5937, 78.9629))  # Default: India center
    lat, lon = coords

    url = (
        f"https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}"
        f"&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,windspeed_10m_max"
        f"&timezone=Asia%2FKolkata&forecast_days=7"
    )

    try:
        resp = httpx.get(url, timeout=10)
        data = resp.json().get("daily", {})
        return {
            "dates": data.get("time", []),
            "temp_max": data.get("temperature_2m_max", []),
            "temp_min": data.get("temperature_2m_min", []),
            "precipitation": data.get("precipitation_sum", []),
            "wind": data.get("windspeed_10m_max", []),
        }
    except Exception as e:
        return {"error": str(e)}
