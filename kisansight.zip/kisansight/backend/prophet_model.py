import pandas as pd
from prophet import Prophet
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "prices.csv")

def get_forecast(commodity: str, state: str) -> dict:
    df = pd.read_csv(DATA_PATH, parse_dates=["Date"])

    filtered = df[(df["Commodity"] == commodity) & (df["State"] == state)].copy()
    if filtered.empty:
        filtered = df[df["Commodity"] == commodity].copy()

    # Prophet requires ds (date) and y (value)
    ts = (
        filtered.groupby("Date")["Modal_Price_INR_Quintal"]
        .mean()
        .reset_index()
        .rename(columns={"Date": "ds", "Modal_Price_INR_Quintal": "y"})
        .dropna()
        .sort_values("ds")
    )

    if len(ts) < 10:
        return {"error": "Not enough data for this selection."}

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=False,
        daily_seasonality=False,
        changepoint_prior_scale=0.15,
    )
    model.fit(ts)

    future = model.make_future_dataframe(periods=7, freq="D")
    forecast_df = model.predict(future)

    # Last 30 historical + 7 days forecast
    historical = ts.tail(30).rename(columns={"ds": "date", "y": "price"})
    future_preds = forecast_df.tail(7)[["ds", "yhat", "yhat_lower", "yhat_upper"]].rename(
        columns={"ds": "date", "yhat": "price", "yhat_lower": "lower", "yhat_upper": "upper"}
    )

    today_price = float(ts["y"].iloc[-1])
    max_future = float(future_preds["price"].max())
    signal = "SELL TODAY" if today_price >= max_future * 0.97 else "WAIT 3 DAYS"
    wait_price = float(future_preds["price"].iloc[2])
    gain_pct = round((wait_price - today_price) / today_price * 100, 1)

    return {
        "signal": signal,
        "today_price": round(today_price, 2),
        "predicted_price_3d": round(wait_price, 2),
        "gain_pct": gain_pct,
        "historical": historical.to_dict(orient="records"),
        "forecast": future_preds.to_dict(orient="records"),
    }
