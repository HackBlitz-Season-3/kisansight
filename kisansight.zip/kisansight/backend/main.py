from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from prophet_model import get_forecast
from weather import get_weather
from news import get_news
from explain import get_explanation
import pandas as pd

app = FastAPI(title="KisanSight API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/commodities")
def list_commodities():
    df = pd.read_csv("data/prices.csv")
    return {"commodities": sorted(df["Commodity"].unique().tolist())}

@app.get("/api/states")
def list_states():
    df = pd.read_csv("data/prices.csv")
    return {"states": sorted(df["State"].unique().tolist())}

@app.get("/api/predict")
def predict(
    commodity: str = Query(...),
    state: str = Query(...),
    lang: str = Query("en"),
):
    forecast = get_forecast(commodity, state)
    weather = get_weather(state)
    news = get_news(commodity)
    explanation = get_explanation(forecast, weather, commodity, state, lang)
    return {
        "commodity": commodity,
        "state": state,
        "forecast": forecast,
        "weather": weather,
        "news": news,
        "explanation": explanation,
    }
