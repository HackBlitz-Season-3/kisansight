import httpx
import os

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_FREE_KEY_HERE")
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

LANG_NAMES = {"en": "English", "hi": "Hindi", "mr": "Marathi"}

SYSTEM_PROMPT = """You are KisanSight, an AI assistant for Indian farmers.
Given price forecast data, generate a SHORT (2-3 sentences), SIMPLE explanation
in {lang} that a farmer with basic literacy can understand.
Tell them: 1) What will happen to price in next 3 days 2) Whether to sell now or wait.
Be direct. Use simple words. No technical jargon."""

def get_explanation(forecast: dict, weather: dict, commodity: str, state: str, lang: str) -> str:
    if "error" in forecast:
        return forecast["error"]

    lang_name = LANG_NAMES.get(lang, "English")
    signal = forecast.get("signal", "")
    today = forecast.get("today_price", 0)
    pred_3d = forecast.get("predicted_price_3d", 0)
    gain = forecast.get("gain_pct", 0)

    rain = ""
    if weather and "precipitation" in weather and weather["precipitation"]:
        avg_rain = sum(weather["precipitation"][:3]) / 3
        rain = f"Expected rainfall next 3 days: {avg_rain:.1f}mm."

    prompt = (
        f"Commodity: {commodity}, State: {state}. "
        f"Today's price: ₹{today}/quintal. "
        f"Predicted price in 3 days: ₹{pred_3d}/quintal ({gain:+.1f}%). "
        f"Signal: {signal}. {rain}"
        f"\n\nExplain this to a farmer in 2-3 simple sentences in {lang_name}."
    )

    try:
        resp = httpx.post(
            f"{GEMINI_URL}?key={GEMINI_API_KEY}",
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=15,
        )
        result = resp.json()
        return result["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        # Fallback plain English
        if signal == "SELL TODAY":
            return f"Today's {commodity} price is ₹{today}/quintal. Our forecast shows prices may not rise much. We recommend selling today."
        else:
            return f"Today's {commodity} price is ₹{today}/quintal. Prices are expected to rise to ₹{pred_3d} in 3 days (+{gain}%). Consider waiting to sell."
