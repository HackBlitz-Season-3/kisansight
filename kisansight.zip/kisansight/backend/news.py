import httpx
import os

NEWSDATA_API_KEY = os.getenv("NEWSDATA_API_KEY", "YOUR_FREE_KEY_HERE")

def get_news(commodity: str) -> list:
    try:
        url = (
            f"https://newsdata.io/api/1/news"
            f"?apikey={NEWSDATA_API_KEY}"
            f"&q={commodity}+price+India+mandi"
            f"&language=en&country=in&category=business"
        )
        resp = httpx.get(url, timeout=10)
        articles = resp.json().get("results", [])[:5]
        return [
            {
                "title": a.get("title", ""),
                "description": a.get("description", ""),
                "url": a.get("link", ""),
                "published": a.get("pubDate", ""),
                "source": a.get("source_id", ""),
            }
            for a in articles
        ]
    except Exception:
        return []
